var Hangman = /** @class */ (function () {
    function Hangman() {
        this.woerter = ["baum", "strauch", "ottomane", "hamster"];
        this.versuche = 0;
        this.geraten = "";
        this.wort = "";
        var r = this.randomInt(0, this.woerter.length);
        this.wort = this.woerter[r];
        this.geraten = this.erzeugeLeer();
    }
    Hangman.prototype.randomInt = function (min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    };
    Hangman.prototype.erzeugeLeer = function () {
        var n = "";
        for (var i = 0; i < this.wort.length; i++) {
            n = n + '_';
        }
        return n;
    };
    Hangman.prototype.ausgabe = function () {
        return this.geraten;
    };
    Hangman.prototype.einsetzen = function (b) {
        var leer = "";
        for (var i = 0; i < this.wort.length; i++) {
            if (this.wort[i] == b) {
                leer = leer + b;
            }
            else {
                leer = leer + this.geraten[i];
            }
        }
        this.geraten = leer;
    };
    Hangman.prototype.richtig = function () {
        return (this.geraten == this.wort);
    };
    return Hangman;
}());
var DrawingApp = /** @class */ (function () {
    function DrawingApp() {
        var _this = this;
        this.hangman = new Hangman();
        this.clearEventHandler = function () {
            _this.context.clearRect(0, 0, _this.canvas.width, _this.canvas.height);
            _this.hangman = new Hangman();
            _this.wort.innerText = _this.hangman.ausgabe();
        };
        this.getBuchstabe = function (e) {
            var formData = new FormData(_this.form);
            var b = formData.get("buchstabe");
            _this.form.reset();
            _this.hangman.einsetzen(b[0].toLowerCase());
            _this.wort.innerText = _this.hangman.ausgabe();
            _this.hangman.versuche++;
            if (_this.hangman.richtig()) {
                _this.wort.innerText = "fertig";
            }
            _this.redraw();
            e.preventDefault(); // verhütet reload der ganzen Seite
        };
        this.canvas = document.getElementById('canvas');
        this.clear = document.getElementById('neustart');
        this.wort = document.getElementById('wort');
        this.form = document.querySelector("#formB");
        this.context = this.canvas.getContext("2d");
        this.context.lineCap = 'round';
        this.context.lineJoin = 'round';
        this.context.strokeStyle = 'black';
        this.context.lineWidth = 1;
        this.wort.innerText = this.hangman.ausgabe();
        this.wort.style.letterSpacing = "30px";
        this.createUserEvents();
    }
    DrawingApp.prototype.redraw = function () {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.context.beginPath();
        this.context.moveTo(1, 1);
        for (var i = 0; i < this.hangman.versuche; i++) {
            var x = this.hangman.randomInt(1, 500);
            var y = this.hangman.randomInt(1, 500);
            this.context.lineTo(x, y);
        }
        this.context.stroke();
        this.context.closePath();
    };
    DrawingApp.prototype.createUserEvents = function () {
        this.clear.addEventListener("click", this.clearEventHandler);
        this.form.addEventListener("submit", this.getBuchstabe);
    };
    return DrawingApp;
}());
new DrawingApp();
//# sourceMappingURL=paint.js.map