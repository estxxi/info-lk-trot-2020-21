class Hangman {
    private woerter: Array<string> = ["baum", "strauch", "ottomane", "hamster"];
    public versuche: number = 0;
    private geraten: string = "";
    private wort: string = "";
    public randomInt(min: number, max: number): number {
        return Math.floor(Math.random()*(max-min))+min;
     }
    private erzeugeLeer(): string {
        let n: string = "";
        for (let i=0; i<this.wort.length; i++) {
            n = n + '_';
        }
        return n;
    }
    public ausgabe() {
        return this.geraten;
    }
    public einsetzen(b:string) {
        let leer: string = "";
        for (let i=0; i<this.wort.length; i++) {
            if (this.wort[i]==b){
                leer = leer + b;
            } else {
                leer = leer + this.geraten[i];
            }
        }
        this.geraten = leer;
    }
    public richtig(){
        return (this.geraten==this.wort);
    }
    constructor(){
        const r = this.randomInt(0,this.woerter.length);
        this.wort = this.woerter[r];
        this.geraten = this.erzeugeLeer();
    }
}


class DrawingApp {
    // siehe https://developer.mozilla.org/en-US/docs/Web/API#interfaces
    private canvas: HTMLCanvasElement;
    private context: CanvasRenderingContext2D;
    private clear: HTMLButtonElement;
    private wort: HTMLElement;
    private form: HTMLFormElement;
    private hangman: Hangman = new Hangman();
        
    constructor() {
        this.canvas = document.getElementById('canvas') as HTMLCanvasElement;
        this.clear = document.getElementById('neustart') as HTMLButtonElement;
        this.wort = document.getElementById('wort') as HTMLElement;
        this.form = document.querySelector("#formB") as HTMLFormElement;

        this.context = this.canvas.getContext("2d");
        this.context.lineCap = 'round';
        this.context.lineJoin = 'round';
        this.context.strokeStyle = 'black';
        this.context.lineWidth = 1;

        this.wort.innerText = this.hangman.ausgabe();
        this.wort.style.letterSpacing = "30px";
        
        this.createUserEvents();
    }
    private redraw() {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.context.beginPath();
        this.context.moveTo(1,1);
        for (var i: number = 0; i<this.hangman.versuche; i++){
            const x = this.hangman.randomInt(1,500);
            const y = this.hangman.randomInt(1,500);
            this.context.lineTo(x,y);
        }
        this.context.stroke();
        this.context.closePath();
    }
    private createUserEvents() {
        this.clear.addEventListener("click", this.clearEventHandler);
        this.form.addEventListener("submit", this.getBuchstabe);
    }
    private clearEventHandler = () => {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.hangman = new Hangman();
        this.wort.innerText = this.hangman.ausgabe();
    }
    private getBuchstabe = (e: Event) => {
        const formData = new FormData(this.form);
        const b = formData.get("buchstabe") as string;
        this.form.reset();
        this.hangman.einsetzen(b[0].toLowerCase())
        this.wort.innerText = this.hangman.ausgabe();
        this.hangman.versuche++;
        if (this.hangman.richtig()){
            this.wort.innerText="fertig";
        }
        this.redraw();
        e.preventDefault(); // verhütet reload der ganzen Seite
    }
    
}

new DrawingApp();
